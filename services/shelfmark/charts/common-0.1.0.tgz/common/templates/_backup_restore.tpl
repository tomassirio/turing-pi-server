{{/*
Restore InitContainer
Params:
  - .Values: The values context
  - .AppName: The name of the application (e.g. sonarr)
  - .ConfigPath: The path where config is mounted (default: /config)
*/}}
{{- define "common.restore.initContainer" -}}
{{- $appName := .AppName -}}
{{- $configPath := .ConfigPath | default "/config" -}}
- name: restore-config
  image: instrumentisto/rsync-ssh:latest
  imagePullPolicy: IfNotPresent
  command: ["/bin/sh", "-c"]
  args:
    - |
      set -e
      echo "🔄 Restoring config from backup..."
      mkdir -p {{ $configPath }}
      if [ -d "/restore-source/{{ $appName }}" ]; then
        echo "📦 Found backup, syncing..."
        # First, count total files
        total=$(rsync -a --dry-run --stats --delete --no-o --no-g /restore-source/{{ $appName }}/ {{ $configPath }}/ | grep "Number of regular files transferred:" | awk '{print $6}')
        echo "📊 Files to transfer: $total"
        # Now do actual transfer with verbose output and counter
        rsync -av --delete --no-o --no-g /restore-source/{{ $appName }}/ {{ $configPath }}/ | awk -v total="$total" 'BEGIN{count=0} !/\/$/ && !/sending incremental/ && !/sent.*received/ && !/total size/ && NF>0 && !/^$/ {count++; printf "[%d/%s] %s\n", count, total, $0}'
        echo ""
        echo "✅ Restore complete."
      else
        echo "⚠️ No backup found at /restore-source/{{ $appName }}, starting fresh."
      fi
      exit 0
  volumeMounts:
    - name: config
      mountPath: {{ $configPath }}
    - name: {{ if eq .Values.persistence.restore.existingClaim .Values.persistence.backup.existingClaim }}backup{{ else }}restore{{ end }}
      mountPath: /restore-source
      readOnly: true
{{- end -}}

{{/*
Backup Sidecar Container
Params:
  - .Values: The values context
  - .AppName: The name of the application (e.g. sonarr)
  - .ConfigPath: The path where config is mounted (default: /config)

Manual backup trigger:
  kubectl exec -it <pod-name> -c backup-config -- touch /tmp/trigger-backup
*/}}
{{- define "common.backup.sidecar" -}}
{{- $appName := .AppName -}}
{{- $configPath := .ConfigPath | default "/config" -}}
- name: backup-config
  image: instrumentisto/rsync-ssh:latest
  imagePullPolicy: IfNotPresent
  command: ["/bin/sh", "-c"]
  args:
    - |
      do_backup() {
        echo "🚀 Starting backup..."
        mkdir -p /backup-dest/{{ $appName }}
        # First, count total files
        total=$(rsync -a --dry-run --stats --delete --no-o --no-g {{ $configPath }}/ /backup-dest/{{ $appName }}/ | grep "Number of regular files transferred:" | awk '{print $6}')
        echo "📊 Files to transfer: $total"
        # Now do actual transfer with verbose output and counter
        rsync -av --delete --no-o --no-g {{ $configPath }}/ /backup-dest/{{ $appName }}/ | awk -v total="$total" 'BEGIN{count=0} !/\/$/ && !/sending incremental/ && !/sent.*received/ && !/total size/ && NF>0 && !/^$/ {count++; printf "[%d/%s] %s\n", count, total, $0}'
        echo ""
        echo "✅ Backup completed at $(date)"
      }

      echo "⏰ Starting backup scheduler..."
      echo "💡 Tip: Trigger manual backup with: kubectl exec -it <pod> -c backup-config -- touch /tmp/trigger-backup"
      while true; do
        # Check for manual trigger
        if [ -f /tmp/trigger-backup ]; then
          echo "🔔 Manual backup triggered!"
          rm -f /tmp/trigger-backup
          do_backup
          continue
        fi

        # Get current time
        current_hour=$(date +%H | sed 's/^0//')
        current_min=$(date +%M | sed 's/^0//')
        current_sec=$(date +%S | sed 's/^0//')
        
        # Calculate seconds since midnight today
        seconds_since_midnight=$((current_hour * 3600 + current_min * 60 + current_sec))
        
        # Target is 2 AM (7200 seconds since midnight)
        target_seconds=7200
        
        if [ $seconds_since_midnight -lt $target_seconds ]; then
          # Before 2 AM today - wait until 2 AM today
          sleep_seconds=$((target_seconds - seconds_since_midnight))
        else
          # After 2 AM - wait until 2 AM tomorrow (86400 = seconds in a day)
          sleep_seconds=$((86400 - seconds_since_midnight + target_seconds))
        fi
        
        echo "💤 Next scheduled backup in $sleep_seconds seconds (2 AM)..."

        # Sleep in short intervals to check for manual trigger
        elapsed=0
        while [ $elapsed -lt $sleep_seconds ]; do
          sleep 10
          elapsed=$((elapsed + 10))
          # Check for manual trigger during wait
          if [ -f /tmp/trigger-backup ]; then
            echo "🔔 Manual backup triggered!"
            rm -f /tmp/trigger-backup
            do_backup
            break
          fi
        done

        # If we completed the full wait (no manual trigger), do scheduled backup
        if [ $elapsed -ge $sleep_seconds ]; then
          do_backup
        fi
      done
  volumeMounts:
    - name: config
      mountPath: {{ $configPath }}
    - name: backup
      mountPath: /backup-dest
{{- end -}}

{{/*
Calibre Database Init Container
Creates an empty Calibre database if one doesn't exist
This allows Calibre-Web to start without requiring a full Calibre deployment
Params:
  - .BooksPath: The path where books are mounted (default: /books)
*/}}
{{- define "common.calibre.dbInitContainer" -}}
{{- $booksPath := .BooksPath | default "/books" -}}
- name: init-calibre-db
  image: alpine:latest
  imagePullPolicy: IfNotPresent
  command: ["/bin/sh", "-c"]
  args:
    - |
      set -e
      echo "🔍 Checking for Calibre database..."

      DB_PATH="{{ $booksPath }}/metadata.db"

      if [ -f "$DB_PATH" ]; then
        echo "✅ Found existing Calibre database at $DB_PATH"
        echo "📊 Database size: $(du -h $DB_PATH | cut -f1)"
        exit 0
      fi

      echo "⚠️  No Calibre database found at $DB_PATH"
      echo "📚 Creating empty Calibre database..."

      # Install sqlite3
      apk add --no-cache sqlite

      # Create the database with minimal Calibre schema
      sqlite3 "$DB_PATH" << 'EOSQL'
-- Core tables for Calibre database
CREATE TABLE authors (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL COLLATE NOCASE,
  sort TEXT COLLATE NOCASE,
  link TEXT NOT NULL DEFAULT ""
);

CREATE TABLE books (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL DEFAULT 'Unknown' COLLATE NOCASE,
  sort TEXT COLLATE NOCASE,
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  pubdate TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  series_index REAL NOT NULL DEFAULT 1.0,
  author_sort TEXT COLLATE NOCASE,
  isbn TEXT DEFAULT "" COLLATE NOCASE,
  lccn TEXT DEFAULT "" COLLATE NOCASE,
  path TEXT NOT NULL DEFAULT "",
  flags INTEGER NOT NULL DEFAULT 1,
  uuid TEXT,
  has_cover BOOL DEFAULT 0,
  last_modified TIMESTAMP NOT NULL DEFAULT "2000-01-01 00:00:00+00:00"
);

CREATE TABLE books_authors_link (
  id INTEGER PRIMARY KEY,
  book INTEGER NOT NULL,
  author INTEGER NOT NULL,
  UNIQUE(book, author)
);

CREATE TABLE books_languages_link (
  id INTEGER PRIMARY KEY,
  book INTEGER NOT NULL,
  lang_code INTEGER NOT NULL,
  item_order INTEGER NOT NULL DEFAULT 0,
  UNIQUE(book, lang_code)
);

CREATE TABLE books_publishers_link (
  id INTEGER PRIMARY KEY,
  book INTEGER NOT NULL,
  publisher INTEGER NOT NULL,
  UNIQUE(book)
);

CREATE TABLE books_ratings_link (
  id INTEGER PRIMARY KEY,
  book INTEGER NOT NULL,
  rating INTEGER NOT NULL,
  UNIQUE(book, rating)
);

CREATE TABLE books_series_link (
  id INTEGER PRIMARY KEY,
  book INTEGER NOT NULL,
  series INTEGER NOT NULL,
  UNIQUE(book)
);

CREATE TABLE books_tags_link (
  id INTEGER PRIMARY KEY,
  book INTEGER NOT NULL,
  tag INTEGER NOT NULL,
  UNIQUE(book, tag)
);

CREATE TABLE comments (
  id INTEGER PRIMARY KEY,
  book INTEGER NOT NULL,
  text TEXT NOT NULL COLLATE NOCASE,
  UNIQUE(book)
);

CREATE TABLE conversion_options (
  id INTEGER PRIMARY KEY,
  format TEXT NOT NULL COLLATE NOCASE,
  book INTEGER,
  data BLOB NOT NULL,
  UNIQUE(format, book)
);

CREATE TABLE custom_columns (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  label TEXT NOT NULL,
  name TEXT NOT NULL,
  datatype TEXT NOT NULL,
  mark_for_delete BOOL DEFAULT 0 NOT NULL,
  editable BOOL DEFAULT 1 NOT NULL,
  display TEXT DEFAULT "{}" NOT NULL,
  is_multiple BOOL DEFAULT 0 NOT NULL,
  normalized BOOL NOT NULL,
  UNIQUE(label)
);

CREATE TABLE data (
  id INTEGER PRIMARY KEY,
  book INTEGER NOT NULL,
  format TEXT NOT NULL COLLATE NOCASE,
  uncompressed_size INTEGER NOT NULL,
  name TEXT NOT NULL,
  UNIQUE(book, format)
);

CREATE TABLE feeds (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  script TEXT NOT NULL
);

CREATE TABLE identifiers (
  id INTEGER PRIMARY KEY,
  book INTEGER NOT NULL,
  type TEXT NOT NULL DEFAULT "isbn" COLLATE NOCASE,
  val TEXT NOT NULL COLLATE NOCASE,
  UNIQUE(book, type)
);

CREATE TABLE languages (
  id INTEGER PRIMARY KEY,
  lang_code TEXT NOT NULL COLLATE NOCASE,
  UNIQUE(lang_code)
);

CREATE TABLE library_id (
  id INTEGER PRIMARY KEY,
  uuid TEXT NOT NULL,
  UNIQUE(uuid)
);

CREATE TABLE metadata_dirtied (
  id INTEGER PRIMARY KEY,
  book INTEGER NOT NULL,
  UNIQUE(book)
);

CREATE TABLE preferences (
  id INTEGER PRIMARY KEY,
  key TEXT NOT NULL,
  val TEXT NOT NULL,
  UNIQUE(key)
);

CREATE TABLE publishers (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL COLLATE NOCASE,
  sort TEXT COLLATE NOCASE,
  UNIQUE(name)
);

CREATE TABLE ratings (
  id INTEGER PRIMARY KEY,
  rating INTEGER CHECK(rating > -1 AND rating < 11),
  UNIQUE(rating)
);

CREATE TABLE series (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL COLLATE NOCASE,
  sort TEXT COLLATE NOCASE,
  UNIQUE(name)
);

CREATE TABLE tags (
  id INTEGER PRIMARY KEY,
  name TEXT NOT NULL COLLATE NOCASE,
  UNIQUE(name)
);

-- Indexes for better performance
CREATE INDEX authors_idx ON authors (name COLLATE NOCASE);
CREATE INDEX books_idx ON books (sort COLLATE NOCASE);
CREATE INDEX books_authors_link_aidx ON books_authors_link (author);
CREATE INDEX books_authors_link_bidx ON books_authors_link (book);
CREATE INDEX books_languages_link_aidx ON books_languages_link (lang_code);
CREATE INDEX books_languages_link_bidx ON books_languages_link (book);
CREATE INDEX books_publishers_link_aidx ON books_publishers_link (publisher);
CREATE INDEX books_publishers_link_bidx ON books_publishers_link (book);
CREATE INDEX books_ratings_link_aidx ON books_ratings_link (rating);
CREATE INDEX books_ratings_link_bidx ON books_ratings_link (book);
CREATE INDEX books_series_link_aidx ON books_series_link (series);
CREATE INDEX books_series_link_bidx ON books_series_link (book);
CREATE INDEX books_tags_link_aidx ON books_tags_link (tag);
CREATE INDEX books_tags_link_bidx ON books_tags_link (book);
CREATE INDEX comments_idx ON comments (book);
CREATE INDEX data_idx ON data (book);
CREATE INDEX formats_idx ON data (format);
CREATE INDEX identifiers_idx ON identifiers (book);
CREATE INDEX languages_idx ON languages (lang_code COLLATE NOCASE);
CREATE INDEX publishers_idx ON publishers (name COLLATE NOCASE);
CREATE INDEX series_idx ON series (name COLLATE NOCASE);
CREATE INDEX tags_idx ON tags (name COLLATE NOCASE);

-- Triggers for maintaining sort fields
CREATE TRIGGER books_insert_trg
  AFTER INSERT ON books
  BEGIN
    UPDATE books SET sort=title_sort(NEW.title)
      WHERE id=NEW.id AND sort IS NULL;
  END;

CREATE TRIGGER books_update_trg
  AFTER UPDATE ON books
  BEGIN
    UPDATE books SET sort=title_sort(NEW.title)
      WHERE id=NEW.id AND sort IS NULL;
  END;

-- Insert library UUID
INSERT INTO library_id (uuid) VALUES (lower(hex(randomblob(16))));

-- Insert default preferences for Calibre-Web compatibility
INSERT INTO preferences (key, val) VALUES ('field_metadata', '{}');
EOSQL

      echo ""
      echo "✅ Empty Calibre database created successfully!"
      echo "📍 Location: $DB_PATH"
      echo "📊 Size: $(du -h $DB_PATH | cut -f1)"
      echo ""
      echo "ℹ️  This is an empty library. You can add books through:"
      echo "   - Calibre-Web upload feature"
      echo "   - Calibre desktop application"
      echo "   - Manual file placement (requires metadata update)"
      echo ""
  volumeMounts:
    - name: books
      mountPath: {{ $booksPath }}
{{- end -}}
